function enviar() {
    alert('Usuário não cadastrado!');
}
enviar();